# Backend main script placeholder
print('Backend running')